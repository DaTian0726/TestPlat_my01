package com.juhe.my01.testng.monitor;

/**
 * 使用业务系统模拟报警系统
 */
public class Demo {



}
