package com.juhe.my01.test;

import com.juhe.my01.utils.JDBCUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JdbcTest01 {

    @Autowired
    JDBCUtil  jdbcUtil;

    @Test
    public void test01() {
        Map map = jdbcUtil.queryTeade("200301201909271404441438502");
        System.out.println("查询-----" + map.toString());
    }
}
