package com.juhe.my01.testng.juhe.case01.Barcode_TestCase;

import com.alibaba.fastjson.JSONObject;
import com.juhe.my01.models.juhe.Barcode;
import com.juhe.my01.toapi.API_Version;
import com.juhe.my01.utils.TestSign;
import com.juhe.my01.utils.Undecode_util;
import org.testng.annotations.Test;

public class Barcode_MQ002 {

    @Test
    public void Test01() {
        JSONObject js = Barcode.MQ002Vars();
        js.put("canal", "汇付天下");//渠道
        js.put("url", "https://pay.ipaynow.cn/");//请求地址   api_release/
        js.put("appId", "156817450336917");
        js.put("appKey", "PG8PvI8He8rlmz8ACyvBi17ekjtRPIyQ");
        js.put("mhtOrderNo", "20191010193342Test");
        JSONObject res = API_Version.RequestApi(js);
        System.out.println("请求结果：" + Undecode_util.res(res.toString()));
//        //进行断言
//        String duanyan= ResAssert.Duan(res);
//        System.out.println("断言结果："+duanyan);
//        //进行验签
//        String appKey=js.getString("appKey");
//        String yan= TestSign.CheckSignMD5(res,appKey);
//        System.out.println("验签结果："+yan);
    }
}
