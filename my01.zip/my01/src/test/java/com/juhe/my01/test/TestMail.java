package com.juhe.my01.test;

import com.alibaba.fastjson.JSONObject;
import com.juhe.my01.models.juhe.Model_Refund;
import com.juhe.my01.toapi.ToRefund;
import com.juhe.my01.utils.SendMail_Util;
import com.juhe.my01.utils.Undecode_util;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestMail {
    @Autowired
    private SendMail_Util sendMail_util;
    @Test
    public void Test01(){
        JSONObject js= Model_Refund.Refund_Var();
        js.put("url", "http://192.168.99.54:8790/refund_access/refundOrder");//请求地址
        js.put("appId", "153068756001128");//应用ID
        js.put("appKey", "GCTYm0H0C2vwtrGcXo6SOi6XctYtty3C");//应用Key
        js.put("mhtOrderNo", "20191012170253Test");
        js.put("amount", "1");
        js.put("notifyUrl","http://mock-api.com/0ZzRmXKe.mock/qqq");
        JSONObject res = ToRefund.RequestApi(js);
        System.out.println("请求结果：" + Undecode_util.res( res.getString("body")));
        sendMail_util.sendMail(res,"测试邮件");
    }
}
