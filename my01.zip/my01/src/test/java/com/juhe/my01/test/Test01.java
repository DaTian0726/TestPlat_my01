package com.juhe.my01.test;

public class Test01 {

    public static String main() {

        String ip="sdsfdghjtretweteryt";

        String[] strAaary=ip.split("\\.");

        for (String strtm:strAaary){
            System.out.println(strtm);
            if (Integer.valueOf(strtm).equals("0")){
                System.out.println("success");
                return "success";
            }if(Integer.valueOf(strtm).equals("1")){
                return "false";
            }else{
                break;
            }
        }

        System.out.println("--------"+ip.substring(0,1)+"========"+ip.lastIndexOf(0));
        return null;
    }
}
