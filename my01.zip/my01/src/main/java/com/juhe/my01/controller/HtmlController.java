package com.juhe.my01.controller;

import com.alibaba.fastjson.JSONObject;
import com.juhe.my01.models.juhe.Barcode;
import com.juhe.my01.models.juhe.TradeWap;
import com.juhe.my01.toapi.API_Version;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/html")
public class HtmlController {

    protected static Logger logger = LoggerFactory.getLogger(HtmlController.class);

    @RequestMapping("/index")
    public String hello(ModelMap map) {
        logger.info("访问Controller");
        map.put("name", "张三");
        map.put("age", "123");
        logger.warn("dddd啊实打实上的");
        return "index";
    }

    @RequestMapping("/barcode")
    public String barcaode(ModelMap map) {
        //WP001
        JSONObject object = Barcode.WP001Vars();
        logger.info("\n测试被扫：" + "当前渠道：" + object.getString("canal"));
        JSONObject res = API_Version.RequestApi(object);
        logger.info("\n被扫返回：" + res.toString());
        //MQ002
        JSONObject object1 = Barcode.MQ002Vars();
        JSONObject MQRes=API_Version.RequestApi(object1);
        map.put("res", res.toString());
        map.put("MQRes",MQRes.toString());
        return "index";
    }

    @RequestMapping("/tradewap")
    public String tradewap(ModelMap map) {
        //WP001
        JSONObject object = TradeWap.Wap_WP001();
        logger.info("\n测试：" + "当前渠道：" + object.getString("canal"));
        JSONObject res = API_Version.RequestApi(object);
        logger.info("\n被扫返回：" + res);
        //MQ002
        JSONObject object1 = TradeWap.Wap_MQ002();
        JSONObject MQRes=API_Version.RequestApi(object1);
        map.put("res", res);
        map.put("MQRes",MQRes);
        return "index";
    }

}
