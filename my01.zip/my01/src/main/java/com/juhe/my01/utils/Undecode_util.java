package com.juhe.my01.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class Undecode_util {


    public static String res(String res){
        try {
            res = URLDecoder.decode(res, "UTF-8");
            return res;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return  null;
    }
}
