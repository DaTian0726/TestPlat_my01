package com.juhe.my01.utils;

import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.xml.crypto.Data;
import java.util.Date;

@Service
public class SendMail_Util {

    @Autowired
    private JavaMailSender mailSender;//框架自带的

    @Value("${spring.mail.username}")
    private String from;

    @Async ////意思是异步调用这个方法
    public void sendMail(JSONObject js, String title) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from); // 发送人的邮箱
        message.setSubject(title); //标题
        //发给谁  对方邮箱
        message.setTo(
                "18511304822@163.com"//测试邮件
//                "sunxueting@ipaynow.cn",
//                "wangwei@ipaynow.cn",
//                "qinhailong@ipaynow.cn",
//                "suntao@ipaynow.cn",
//                "xuxiong@ipaynow.cn",
//                "zhangchuanyuan@ipaynow.cn",
//                "qiaomeng@ipaynow.cn",
//                "zhangxiaofei@ipaynow.cn"
        );
        message.setText(
                "测试结果：\n" + js.getString("body" +
                        "\n测试时间---" + GetNowTime.NowTime()
                )
        ); //内容
        mailSender.send(message); //发送
    }
}
