package com.juhe.my01.utils;

import com.juhe.my01.controller.HtmlController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class JDBCUtil {
    protected static Logger logger = LoggerFactory.getLogger(HtmlController.class);

    @Resource
    public  JdbcTemplate jdbcTemplate;

    public  Map queryTeade(String trans_id) {
        String sql = "select * from acp_trans where trans_id=" + "'" + trans_id + "'";
        //查询数据库结果转为map
        Map map = jdbcTemplate.queryForMap(sql);
        if (map.get("trans_id").equals("")) {
            logger.info("\n----未查询到结果，查询sql为：\n"+sql);
        } else {
            logger.info("\n查询SQL为：\n"+sql+"----查询测试环境数据库-结果为：\n" + map.toString());
            return map;
        }
        return null;
    }
}
