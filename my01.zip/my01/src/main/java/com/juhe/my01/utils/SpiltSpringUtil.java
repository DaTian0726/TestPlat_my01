package com.juhe.my01.utils;

public class SpiltSpringUtil {

    /**
     * 打印json格式的数据
     * 前提：字符串格式要为键值对的方式   ’key‘ = ’value‘  使用 ‘&’ 进行拼接
     * @param resp
     * @return
     */

    public static void JsonSys_resp(String resp){
        StringBuffer sb = new StringBuffer();
        sb.append("{\n");
        String[] result_spilt = resp.split("&");
            for (int i = 0; i < result_spilt.length; i++) {
                String[] entry = result_spilt[i].split("=");

                //为检验切割出的键值对出现null的情况，处理逻辑
                if(entry.length == 1){
                    sb.append("\t" + entry[0] + " = " + " 无记录\n");
                }else if (i != result_spilt.length - 1) {
                    sb.append("\t" + entry[0] + " = " + entry[1] + "\n");
                } else {
                    sb.append("\t" + entry[0] + " = " + entry[1]);
                }
            }
            System.out.println(sb.append("\n}").toString());
    }

}
